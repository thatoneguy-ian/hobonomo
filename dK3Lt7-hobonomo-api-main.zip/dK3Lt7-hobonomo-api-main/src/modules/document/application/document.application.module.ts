import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from 'modules/authentication/domain'
import { DocumentDomainModule } from '../domain'
import { DocumentController } from './document.controller'

import { ApplicationDomainModule } from '../../../modules/application/domain'

import { DocumentByApplicationController } from './documentByApplication.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    DocumentDomainModule,

ApplicationDomainModule,

],
  controllers: [
    DocumentController,
    
    DocumentByApplicationController,
    
  ],
  providers: [],
})
export class DocumentApplicationModule {}
