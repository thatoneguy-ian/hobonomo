import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { DocumentDomainFacade } from 'modules/document/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { DocumentApplicationEvent } from './document.application.event'
import { DocumentCreateDto } from './document.dto'

import { ApplicationDomainFacade } from '../../application/domain'

@Controller('/v1/applications')
export class DocumentByApplicationController {
  constructor(
    
    private applicationDomainFacade: ApplicationDomainFacade,
    
    private documentDomainFacade: DocumentDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/application/:applicationId/documents')
  async findManyApplicationId(
    @Param('applicationId') applicationId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const application =
      await this.applicationDomainFacade.findOneByIdOrFail(
        applicationId,
      )

    const items =
      await this.documentDomainFacade.findManyByApplication(
        application,
        queryOptions,
      )

    return items
  }

  @Post('/application/:applicationId/documents')
  async createByApplicationId(
    @Param('applicationId') applicationId: string,
    @Body() body: DocumentCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, applicationId }

    const item = await this.documentDomainFacade.create(valuesUpdated)

    await this.eventService.emit<DocumentApplicationEvent.DocumentCreated.Payload>(
      DocumentApplicationEvent
        .DocumentCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
