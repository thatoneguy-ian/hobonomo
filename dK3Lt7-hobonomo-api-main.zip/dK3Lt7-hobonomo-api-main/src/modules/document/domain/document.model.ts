import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Application } from '../../../modules/application/domain'

@Entity()
export class Document {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

filePath: string

@Column({})

applicationId: string

@ManyToOne(
  () => Application,
  parent => parent.documents,
  )
  @JoinColumn({ name: 'applicationId' })

application?: Application

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
