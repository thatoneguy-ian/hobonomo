import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { CompanyDomainModule } from './company/domain'

import { JobDomainModule } from './job/domain'

import { ApplicationDomainModule } from './application/domain'

import { DocumentDomainModule } from './document/domain'

import { JobdescriptionDomainModule } from './jobdescription/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

CompanyDomainModule,

JobDomainModule,

ApplicationDomainModule,

DocumentDomainModule,

JobdescriptionDomainModule,

],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
