import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Company } from '../../../modules/company/domain'

import { Application } from '../../../modules/application/domain'

import { Jobdescription } from '../../../modules/jobdescription/domain'

@Entity()
export class Job {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

title: string

@ColumnNumeric({"nullable":true,"type":"numeric"})

salary?: number

@Column({"nullable":true})

openingDate?: string

@Column({})

companyId: string

@ManyToOne(
  () => Company,
  parent => parent.jobs,
  )
  @JoinColumn({ name: 'companyId' })

company?: Company

@OneToMany(
  () => Application,
  child => child.job,
  )

applications?: Application[]

@OneToMany(
  () => Jobdescription,
  child => child.job,
  )

jobdescriptions?: Jobdescription[]

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
