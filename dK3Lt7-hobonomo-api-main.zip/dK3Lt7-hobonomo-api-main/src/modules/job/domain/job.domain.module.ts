import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { JobDomainFacade } from './job.domain.facade'
import { Job } from './job.model'

@Module({
  imports: [
    TypeOrmModule.forFeature([Job]),
    DatabaseHelperModule,
  ],
  providers: [
    JobDomainFacade,
    JobDomainFacade,
  ],
  exports: [JobDomainFacade],
})
export class JobDomainModule {}
