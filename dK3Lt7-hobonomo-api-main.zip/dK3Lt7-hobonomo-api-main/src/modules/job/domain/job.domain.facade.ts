import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { Job } from './job.model'

import { Company } from '../../company/domain'

@Injectable()
export class JobDomainFacade {
  constructor(
    @InjectRepository(Job)
    private repository: Repository<Job>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(
    values: Partial<Job>,
  ): Promise<Job> {
    return this.repository.save(values)
  }

  async update(
    item: Job,
    values: Partial<Job>,
  ): Promise<Job> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: Job): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<Job> = {},
  ): Promise<Job[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<Job> = {},
  ): Promise<Job> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

async findManyByCompany(
    company: Company,
    queryOptions: RequestHelper.QueryOptions<Job> = {},
  ): Promise<Job[]> {
    if (!company) {
      this.databaseHelper.invalidQueryWhere('company')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        companyId: company.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

}
