import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from 'libraries/event'
import {
  Job,
  JobDomainFacade,
} from 'modules/job/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { JobApplicationEvent } from './job.application.event'
import {
  JobCreateDto,
  JobUpdateDto,
} from './job.dto'

@Controller('/v1/jobs')
export class JobController {
  constructor(
    private eventService: EventService,
    private jobDomainFacade: JobDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.jobDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: JobCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.jobDomainFacade.create(body)

    await this.eventService.emit<JobApplicationEvent.JobCreated.Payload>(
      JobApplicationEvent
        .JobCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:jobId')
  async findOne(
    @Param('jobId') jobId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item =
      await this.jobDomainFacade.findOneByIdOrFail(
        jobId,
        queryOptions,
      )

    return item
  }

  @Patch('/:jobId')
  async update(
    @Param('jobId') jobId: string,
    @Body() body: JobUpdateDto,
  ) {
    const item =
      await this.jobDomainFacade.findOneByIdOrFail(
        jobId,
      )

    const itemUpdated = await this.jobDomainFacade.update(
      item,
      body as Partial<Job>,
    )
    return itemUpdated
  }

  @Delete('/:jobId')
  async delete(@Param('jobId') jobId: string) {
    const item =
      await this.jobDomainFacade.findOneByIdOrFail(
        jobId,
      )

    await this.jobDomainFacade.delete(item)

    return item
  }
}
