export namespace JobApplicationEvent {
  export namespace JobCreated {
    export const key = 'job.application.job.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
