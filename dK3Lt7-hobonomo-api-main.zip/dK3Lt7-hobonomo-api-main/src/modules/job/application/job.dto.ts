import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class JobCreateDto {

@IsString()

@IsNotEmpty()
  title: string

@IsNumber()

@IsOptional()
  salary?: number

@IsString()

@IsOptional()
  openingDate?: string

@IsString()

@IsOptional()
  dateCreated?: string

@IsString()

@IsOptional()
  dateDeleted?: string

@IsString()

@IsOptional()
  dateUpdated?: string

@IsString()

@IsOptional()
  companyId?: string

}

export class JobUpdateDto {

@IsString()

@IsOptional()
  title?: string

@IsNumber()

@IsOptional()
  salary?: number

@IsString()

@IsOptional()
  openingDate?: string

@IsString()

@IsOptional()
  dateCreated?: string

@IsString()

@IsOptional()
  dateDeleted?: string

@IsString()

@IsOptional()
  dateUpdated?: string

@IsString()

@IsOptional()
  companyId?: string

}
