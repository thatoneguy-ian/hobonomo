import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from 'modules/authentication/domain'
import { JobDomainModule } from '../domain'
import { JobController } from './job.controller'

import { CompanyDomainModule } from '../../../modules/company/domain'

import { JobByCompanyController } from './jobByCompany.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    JobDomainModule,

CompanyDomainModule,

],
  controllers: [
    JobController,
    
    JobByCompanyController,
    
  ],
  providers: [],
})
export class JobApplicationModule {}
