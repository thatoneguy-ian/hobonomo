import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { JobDomainFacade } from 'modules/job/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { JobApplicationEvent } from './job.application.event'
import { JobCreateDto } from './job.dto'

import { CompanyDomainFacade } from '../../company/domain'

@Controller('/v1/companys')
export class JobByCompanyController {
  constructor(
    
    private companyDomainFacade: CompanyDomainFacade,
    
    private jobDomainFacade: JobDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/company/:companyId/jobs')
  async findManyCompanyId(
    @Param('companyId') companyId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const company =
      await this.companyDomainFacade.findOneByIdOrFail(
        companyId,
      )

    const items =
      await this.jobDomainFacade.findManyByCompany(
        company,
        queryOptions,
      )

    return items
  }

  @Post('/company/:companyId/jobs')
  async createByCompanyId(
    @Param('companyId') companyId: string,
    @Body() body: JobCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, companyId }

    const item = await this.jobDomainFacade.create(valuesUpdated)

    await this.eventService.emit<JobApplicationEvent.JobCreated.Payload>(
      JobApplicationEvent
        .JobCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
