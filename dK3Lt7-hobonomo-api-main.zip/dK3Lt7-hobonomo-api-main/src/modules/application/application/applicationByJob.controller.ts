import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { ApplicationDomainFacade } from 'modules/application/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { ApplicationApplicationEvent } from './application.application.event'
import { ApplicationCreateDto } from './application.dto'

import { JobDomainFacade } from '../../job/domain'

@Controller('/v1/jobs')
export class ApplicationByJobController {
  constructor(
    
    private jobDomainFacade: JobDomainFacade,
    
    private applicationDomainFacade: ApplicationDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/job/:jobId/applications')
  async findManyJobId(
    @Param('jobId') jobId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const job =
      await this.jobDomainFacade.findOneByIdOrFail(
        jobId,
      )

    const items =
      await this.applicationDomainFacade.findManyByJob(
        job,
        queryOptions,
      )

    return items
  }

  @Post('/job/:jobId/applications')
  async createByJobId(
    @Param('jobId') jobId: string,
    @Body() body: ApplicationCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, jobId }

    const item = await this.applicationDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ApplicationApplicationEvent.ApplicationCreated.Payload>(
      ApplicationApplicationEvent
        .ApplicationCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
