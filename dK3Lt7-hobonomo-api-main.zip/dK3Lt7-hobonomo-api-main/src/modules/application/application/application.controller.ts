import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from 'libraries/event'
import {
  Application,
  ApplicationDomainFacade,
} from 'modules/application/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ApplicationApplicationEvent } from './application.application.event'
import {
  ApplicationCreateDto,
  ApplicationUpdateDto,
} from './application.dto'

@Controller('/v1/applications')
export class ApplicationController {
  constructor(
    private eventService: EventService,
    private applicationDomainFacade: ApplicationDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.applicationDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: ApplicationCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.applicationDomainFacade.create(body)

    await this.eventService.emit<ApplicationApplicationEvent.ApplicationCreated.Payload>(
      ApplicationApplicationEvent
        .ApplicationCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:applicationId')
  async findOne(
    @Param('applicationId') applicationId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item =
      await this.applicationDomainFacade.findOneByIdOrFail(
        applicationId,
        queryOptions,
      )

    return item
  }

  @Patch('/:applicationId')
  async update(
    @Param('applicationId') applicationId: string,
    @Body() body: ApplicationUpdateDto,
  ) {
    const item =
      await this.applicationDomainFacade.findOneByIdOrFail(
        applicationId,
      )

    const itemUpdated = await this.applicationDomainFacade.update(
      item,
      body as Partial<Application>,
    )
    return itemUpdated
  }

  @Delete('/:applicationId')
  async delete(@Param('applicationId') applicationId: string) {
    const item =
      await this.applicationDomainFacade.findOneByIdOrFail(
        applicationId,
      )

    await this.applicationDomainFacade.delete(item)

    return item
  }
}
