export namespace ApplicationApplicationEvent {
  export namespace ApplicationCreated {
    export const key = 'application.application.application.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
