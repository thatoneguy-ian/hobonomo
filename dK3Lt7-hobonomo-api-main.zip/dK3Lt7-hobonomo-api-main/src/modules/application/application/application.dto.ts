import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class ApplicationCreateDto {

@IsString()

@IsNotEmpty()
  applicationDate: string

@IsString()

@IsNotEmpty()
  status: string

@IsString()

@IsOptional()
  dateCreated?: string

@IsString()

@IsOptional()
  dateDeleted?: string

@IsString()

@IsOptional()
  dateUpdated?: string

@IsString()

@IsOptional()
  userId?: string

@IsString()

@IsOptional()
  jobId?: string

}

export class ApplicationUpdateDto {

@IsString()

@IsOptional()
  applicationDate?: string

@IsString()

@IsOptional()
  status?: string

@IsString()

@IsOptional()
  dateCreated?: string

@IsString()

@IsOptional()
  dateDeleted?: string

@IsString()

@IsOptional()
  dateUpdated?: string

@IsString()

@IsOptional()
  userId?: string

@IsString()

@IsOptional()
  jobId?: string

}
