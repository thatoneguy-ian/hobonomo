import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from 'modules/authentication/domain'
import { ApplicationDomainModule } from '../domain'
import { ApplicationController } from './application.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { ApplicationByUserController } from './applicationByUser.controller'

import { JobDomainModule } from '../../../modules/job/domain'

import { ApplicationByJobController } from './applicationByJob.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ApplicationDomainModule,

UserDomainModule,

JobDomainModule,

],
  controllers: [
    ApplicationController,
    
    ApplicationByUserController,
    
    ApplicationByJobController,
    
  ],
  providers: [],
})
export class ApplicationApplicationModule {}
