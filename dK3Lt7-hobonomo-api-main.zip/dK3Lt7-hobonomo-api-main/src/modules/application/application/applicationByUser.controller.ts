import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { ApplicationDomainFacade } from 'modules/application/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { ApplicationApplicationEvent } from './application.application.event'
import { ApplicationCreateDto } from './application.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class ApplicationByUserController {
  constructor(
    
    private userDomainFacade: UserDomainFacade,
    
    private applicationDomainFacade: ApplicationDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/user/:userId/applications')
  async findManyUserId(
    @Param('userId') userId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const user =
      await this.userDomainFacade.findOneByIdOrFail(
        userId,
      )

    const items =
      await this.applicationDomainFacade.findManyByUser(
        user,
        queryOptions,
      )

    return items
  }

  @Post('/user/:userId/applications')
  async createByUserId(
    @Param('userId') userId: string,
    @Body() body: ApplicationCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, userId }

    const item = await this.applicationDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ApplicationApplicationEvent.ApplicationCreated.Payload>(
      ApplicationApplicationEvent
        .ApplicationCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
