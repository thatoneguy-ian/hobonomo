import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Job } from '../../../modules/job/domain'

import { Document } from '../../../modules/document/domain'

@Entity()
export class Application {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

applicationDate: string

@Column({})

status: string

@Column({})

userId: string

@ManyToOne(
  () => User,
  parent => parent.applications,
  )
  @JoinColumn({ name: 'userId' })

user?: User

@Column({})

jobId: string

@ManyToOne(
  () => Job,
  parent => parent.applications,
  )
  @JoinColumn({ name: 'jobId' })

job?: Job

@OneToMany(
  () => Document,
  child => child.application,
  )

documents?: Document[]

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
