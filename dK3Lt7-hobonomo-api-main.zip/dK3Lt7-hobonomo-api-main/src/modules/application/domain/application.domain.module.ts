import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ApplicationDomainFacade } from './application.domain.facade'
import { Application } from './application.model'

@Module({
  imports: [
    TypeOrmModule.forFeature([Application]),
    DatabaseHelperModule,
  ],
  providers: [
    ApplicationDomainFacade,
    ApplicationDomainFacade,
  ],
  exports: [ApplicationDomainFacade],
})
export class ApplicationDomainModule {}
