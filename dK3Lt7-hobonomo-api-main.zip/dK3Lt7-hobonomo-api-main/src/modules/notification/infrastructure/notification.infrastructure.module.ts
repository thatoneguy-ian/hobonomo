import { Module } from '@nestjs/common'
import { SocketModule } from 'libraries/socket'
import { AuthorizationDomainModule } from 'modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationCompanySubscriber } from './subscribers/notification.company.subscriber'

import { NotificationJobSubscriber } from './subscribers/notification.job.subscriber'

import { NotificationApplicationSubscriber } from './subscribers/notification.application.subscriber'

import { NotificationDocumentSubscriber } from './subscribers/notification.document.subscriber'

import { NotificationJobdescriptionSubscriber } from './subscribers/notification.jobdescription.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [

NotificationCompanySubscriber,

NotificationJobSubscriber,

NotificationApplicationSubscriber,

NotificationDocumentSubscriber,

NotificationJobdescriptionSubscriber,

],
  exports: [],
})
export class NotificationInfrastructureModule {}
