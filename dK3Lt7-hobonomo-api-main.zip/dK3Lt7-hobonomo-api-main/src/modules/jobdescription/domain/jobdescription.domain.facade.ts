import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { Jobdescription } from './jobdescription.model'

import { Job } from '../../job/domain'

@Injectable()
export class JobdescriptionDomainFacade {
  constructor(
    @InjectRepository(Jobdescription)
    private repository: Repository<Jobdescription>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(
    values: Partial<Jobdescription>,
  ): Promise<Jobdescription> {
    return this.repository.save(values)
  }

  async update(
    item: Jobdescription,
    values: Partial<Jobdescription>,
  ): Promise<Jobdescription> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: Jobdescription): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<Jobdescription> = {},
  ): Promise<Jobdescription[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<Jobdescription> = {},
  ): Promise<Jobdescription> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

async findManyByJob(
    job: Job,
    queryOptions: RequestHelper.QueryOptions<Jobdescription> = {},
  ): Promise<Jobdescription[]> {
    if (!job) {
      this.databaseHelper.invalidQueryWhere('job')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        jobId: job.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

}
