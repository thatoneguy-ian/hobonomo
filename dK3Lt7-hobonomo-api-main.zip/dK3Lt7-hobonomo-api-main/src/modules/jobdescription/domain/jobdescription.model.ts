import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Job } from '../../../modules/job/domain'

@Entity()
export class Jobdescription {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

description: string

@Column({})

jobId: string

@ManyToOne(
  () => Job,
  parent => parent.jobdescriptions,
  )
  @JoinColumn({ name: 'jobId' })

job?: Job

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
