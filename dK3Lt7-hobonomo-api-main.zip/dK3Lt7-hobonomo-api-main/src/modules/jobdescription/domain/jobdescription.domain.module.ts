import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { JobdescriptionDomainFacade } from './jobdescription.domain.facade'
import { Jobdescription } from './jobdescription.model'

@Module({
  imports: [
    TypeOrmModule.forFeature([Jobdescription]),
    DatabaseHelperModule,
  ],
  providers: [
    JobdescriptionDomainFacade,
    JobdescriptionDomainFacade,
  ],
  exports: [JobdescriptionDomainFacade],
})
export class JobdescriptionDomainModule {}
