import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from 'modules/authentication/domain'
import { JobdescriptionDomainModule } from '../domain'
import { JobdescriptionController } from './jobdescription.controller'

import { JobDomainModule } from '../../../modules/job/domain'

import { JobdescriptionByJobController } from './jobdescriptionByJob.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    JobdescriptionDomainModule,

JobDomainModule,

],
  controllers: [
    JobdescriptionController,
    
    JobdescriptionByJobController,
    
  ],
  providers: [],
})
export class JobdescriptionApplicationModule {}
