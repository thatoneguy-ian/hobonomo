export namespace JobdescriptionApplicationEvent {
  export namespace JobdescriptionCreated {
    export const key = 'jobdescription.application.jobdescription.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
