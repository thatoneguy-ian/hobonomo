import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from 'libraries/event'
import {
  Jobdescription,
  JobdescriptionDomainFacade,
} from 'modules/jobdescription/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { JobdescriptionApplicationEvent } from './jobdescription.application.event'
import {
  JobdescriptionCreateDto,
  JobdescriptionUpdateDto,
} from './jobdescription.dto'

@Controller('/v1/jobdescriptions')
export class JobdescriptionController {
  constructor(
    private eventService: EventService,
    private jobdescriptionDomainFacade: JobdescriptionDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.jobdescriptionDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: JobdescriptionCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.jobdescriptionDomainFacade.create(body)

    await this.eventService.emit<JobdescriptionApplicationEvent.JobdescriptionCreated.Payload>(
      JobdescriptionApplicationEvent
        .JobdescriptionCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:jobdescriptionId')
  async findOne(
    @Param('jobdescriptionId') jobdescriptionId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item =
      await this.jobdescriptionDomainFacade.findOneByIdOrFail(
        jobdescriptionId,
        queryOptions,
      )

    return item
  }

  @Patch('/:jobdescriptionId')
  async update(
    @Param('jobdescriptionId') jobdescriptionId: string,
    @Body() body: JobdescriptionUpdateDto,
  ) {
    const item =
      await this.jobdescriptionDomainFacade.findOneByIdOrFail(
        jobdescriptionId,
      )

    const itemUpdated = await this.jobdescriptionDomainFacade.update(
      item,
      body as Partial<Jobdescription>,
    )
    return itemUpdated
  }

  @Delete('/:jobdescriptionId')
  async delete(@Param('jobdescriptionId') jobdescriptionId: string) {
    const item =
      await this.jobdescriptionDomainFacade.findOneByIdOrFail(
        jobdescriptionId,
      )

    await this.jobdescriptionDomainFacade.delete(item)

    return item
  }
}
