import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { JobdescriptionDomainFacade } from 'modules/jobdescription/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { JobdescriptionApplicationEvent } from './jobdescription.application.event'
import { JobdescriptionCreateDto } from './jobdescription.dto'

import { JobDomainFacade } from '../../job/domain'

@Controller('/v1/jobs')
export class JobdescriptionByJobController {
  constructor(
    
    private jobDomainFacade: JobDomainFacade,
    
    private jobdescriptionDomainFacade: JobdescriptionDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/job/:jobId/jobdescriptions')
  async findManyJobId(
    @Param('jobId') jobId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const job =
      await this.jobDomainFacade.findOneByIdOrFail(
        jobId,
      )

    const items =
      await this.jobdescriptionDomainFacade.findManyByJob(
        job,
        queryOptions,
      )

    return items
  }

  @Post('/job/:jobId/jobdescriptions')
  async createByJobId(
    @Param('jobId') jobId: string,
    @Body() body: JobdescriptionCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, jobId }

    const item = await this.jobdescriptionDomainFacade.create(valuesUpdated)

    await this.eventService.emit<JobdescriptionApplicationEvent.JobdescriptionCreated.Payload>(
      JobdescriptionApplicationEvent
        .JobdescriptionCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
