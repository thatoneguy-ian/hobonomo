export namespace CompanyApplicationEvent {
  export namespace CompanyCreated {
    export const key = 'company.application.company.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
