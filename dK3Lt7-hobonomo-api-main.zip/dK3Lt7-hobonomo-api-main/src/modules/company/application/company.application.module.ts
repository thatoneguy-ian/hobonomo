import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from 'modules/authentication/domain'
import { CompanyDomainModule } from '../domain'
import { CompanyController } from './company.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    CompanyDomainModule,
    
  ],
  controllers: [
    CompanyController,
    
  ],
  providers: [],
})
export class CompanyApplicationModule {}
