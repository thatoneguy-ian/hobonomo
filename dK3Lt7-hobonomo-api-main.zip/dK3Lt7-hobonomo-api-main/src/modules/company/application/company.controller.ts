import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from 'libraries/event'
import {
  Company,
  CompanyDomainFacade,
} from 'modules/company/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { CompanyApplicationEvent } from './company.application.event'
import {
  CompanyCreateDto,
  CompanyUpdateDto,
} from './company.dto'

@Controller('/v1/companys')
export class CompanyController {
  constructor(
    private eventService: EventService,
    private companyDomainFacade: CompanyDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.companyDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: CompanyCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.companyDomainFacade.create(body)

    await this.eventService.emit<CompanyApplicationEvent.CompanyCreated.Payload>(
      CompanyApplicationEvent
        .CompanyCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:companyId')
  async findOne(
    @Param('companyId') companyId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item =
      await this.companyDomainFacade.findOneByIdOrFail(
        companyId,
        queryOptions,
      )

    return item
  }

  @Patch('/:companyId')
  async update(
    @Param('companyId') companyId: string,
    @Body() body: CompanyUpdateDto,
  ) {
    const item =
      await this.companyDomainFacade.findOneByIdOrFail(
        companyId,
      )

    const itemUpdated = await this.companyDomainFacade.update(
      item,
      body as Partial<Company>,
    )
    return itemUpdated
  }

  @Delete('/:companyId')
  async delete(@Param('companyId') companyId: string) {
    const item =
      await this.companyDomainFacade.findOneByIdOrFail(
        companyId,
      )

    await this.companyDomainFacade.delete(item)

    return item
  }
}
