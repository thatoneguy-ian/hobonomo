import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { CompanyDomainFacade } from './company.domain.facade'
import { Company } from './company.model'

@Module({
  imports: [
    TypeOrmModule.forFeature([Company]),
    DatabaseHelperModule,
  ],
  providers: [
    CompanyDomainFacade,
    CompanyDomainFacade,
  ],
  exports: [CompanyDomainFacade],
})
export class CompanyDomainModule {}
