import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Job } from '../../../modules/job/domain'

@Entity()
export class Company {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

name: string

@Column({"nullable":true})

industry?: string

@OneToMany(
  () => Job,
  child => child.company,
  )

jobs?: Job[]

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
