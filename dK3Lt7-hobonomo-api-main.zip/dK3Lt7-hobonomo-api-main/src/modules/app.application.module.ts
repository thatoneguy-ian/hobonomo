import { Module } from '@nestjs/common'
import { AuthenticationApplicationModule } from './authentication/application'
import { AuthorizationApplicationModule } from './authorization/application'
import { UserApplicationModule } from './user/application'

import { CompanyApplicationModule } from './company/application'

import { JobApplicationModule } from './job/application'

import { ApplicationApplicationModule } from './application/application'

import { DocumentApplicationModule } from './document/application'

import { JobdescriptionApplicationModule } from './jobdescription/application'

import { AiApplicationModule } from './ai/application/ai.application.module'
import { NotificationApplicationModule } from './notification/application/notification.application.module'

@Module({
  imports: [
    AuthenticationApplicationModule,
    UserApplicationModule,
    AuthorizationApplicationModule,
    NotificationApplicationModule,
    AiApplicationModule,

CompanyApplicationModule,

JobApplicationModule,

ApplicationApplicationModule,

DocumentApplicationModule,

JobdescriptionApplicationModule,

],
  controllers: [],
  providers: [],
})
export class AppApplicationModule {}
