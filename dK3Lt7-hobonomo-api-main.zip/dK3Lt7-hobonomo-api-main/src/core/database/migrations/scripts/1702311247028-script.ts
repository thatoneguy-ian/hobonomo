import { MigrationInterface, QueryRunner } from 'typeorm'

export class Script1702311247028 implements MigrationInterface {
  name = 'Script1702311247028'

  public async up(queryRunner: QueryRunner): Promise<void> {

await queryRunner.query(
      `
        INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('2f785f74-9d0a-475d-8429-10492ab2365b', '1Rick_Pacocha@gmail.com', 'Ojos Azules', 'https://i.imgur.com/YfJQV5z.png', 'Ojos Azules', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('5dab9297-a6ab-4aa1-871f-db252b9abbef', '13Keara72@gmail.com', 'Singapura', 'https://i.imgur.com/YfJQV5z.png', 'Himalayan', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('661629cf-1bd8-4b96-86e4-c01a41d16d27', '19Maida13@hotmail.com', 'Munchkin', 'https://i.imgur.com/YfJQV5z.png', 'Savannah', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('f8001b63-ec4a-4d42-87c6-7765fdeb4ac3', '25Vernon_Windler@hotmail.com', 'Chausie', 'https://i.imgur.com/YfJQV5z.png', 'Siberian', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('f2e134ef-75eb-41b4-a461-6587918347f4', '31Camila_Bernier67@yahoo.com', 'American Wirehair', 'https://i.imgur.com/YfJQV5z.png', 'Donskoy', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('723bb740-32a1-456c-a815-39d87f1de4ea', '37Keeley.Watsica@gmail.com', 'Norwegian Forest Cat', 'https://i.imgur.com/YfJQV5z.png', 'Sphynx', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('49040fe6-75fb-4a5d-b828-b82e15aa7843', '43Corbin_Beer@gmail.com', 'Bengal', 'https://i.imgur.com/YfJQV5z.png', 'Chausie', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('9db46f5a-dbee-41ac-8a91-2734740858b0', '49Marta26@yahoo.com', 'Munchkin', 'https://i.imgur.com/YfJQV5z.png', 'British Shorthair', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('6d8dddb4-fcb9-418f-895d-99d91fd3acf5', '55Jarod.Hamill-Cronin27@gmail.com', 'Turkish Angora', 'https://i.imgur.com/YfJQV5z.png', 'Kurilian Bobtail', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');

INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('864279c1-3bd7-46ac-83fb-e8bb5bc1cb7c', 'Tonkinese', 'Siamese', 'American Bobtail', '64Breana.Huel76@gmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '661629cf-1bd8-4b96-86e4-c01a41d16d27');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('143a43e0-4981-4b73-b3e1-94d6b6d2abe8', 'Snowshoe', 'Donskoy', 'Minskin', '71Ally19@yahoo.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '2f785f74-9d0a-475d-8429-10492ab2365b');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('3a4eedd8-0f40-4669-8e48-3d1a2cdae3bb', 'Norwegian Forest Cat', 'Toyger', 'Russian Blue', '78Anika_Larkin69@hotmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '49040fe6-75fb-4a5d-b828-b82e15aa7843');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('6d6193e1-ddc8-4e14-a529-7a2e80deafa6', 'Himalayan', 'Ojos Azules', 'Nebelung', '85Norval_Thompson10@gmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', 'f2e134ef-75eb-41b4-a461-6587918347f4');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('7bf5953d-159c-4ad8-9bb4-ca304724c514', 'Kurilian Bobtail', 'Birman', 'Abyssinian', '92Orland_Welch68@gmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '5dab9297-a6ab-4aa1-871f-db252b9abbef');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('ae60e8cb-a919-4f63-ad3b-e003ab9cd45e', 'Balinese', 'Peterbald', 'Sphynx', '99Jaylon39@hotmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '49040fe6-75fb-4a5d-b828-b82e15aa7843');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('e63006a1-841e-41b8-ae16-32e51f76372d', 'Balinese', 'American Wirehair', 'Sphynx', '106Noemy38@hotmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('6f62ebd3-42c6-4c04-a0fa-ef1a8deff668', 'Siamese', 'Serengeti', 'Birman', '113Raina20@yahoo.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('c0b8befe-3483-4e8c-b951-b2a1c9a829ed', 'British Shorthair', 'Serengeti', 'Ragdoll', '120Gwen11@gmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '5dab9297-a6ab-4aa1-871f-db252b9abbef');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('0059995e-9984-4461-8d16-bbb1f4816cb7', 'Tonkinese', 'American Bobtail', 'Ocicat', '127Koby.Purdy45@yahoo.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');

INSERT INTO "company" ("id", "name", "industry") VALUES ('32060663-75e1-4a7d-a9e8-96c01223c972', 'Himalayan', 'Bengal');
INSERT INTO "company" ("id", "name", "industry") VALUES ('4a46abec-691c-4aba-adf9-4f4bd9beb2c5', 'Sphynx', 'Snowshoe');
INSERT INTO "company" ("id", "name", "industry") VALUES ('425732d7-4501-4611-bcec-9dc0850e70bd', 'Kurilian Bobtail', 'Siberian');
INSERT INTO "company" ("id", "name", "industry") VALUES ('2b54df6b-e4e7-4441-8a99-cb1fefd12a64', 'LaPerm', 'Peterbald');
INSERT INTO "company" ("id", "name", "industry") VALUES ('30196673-7503-4c1f-9423-2e61c071bd3d', 'Siberian', 'Chausie');
INSERT INTO "company" ("id", "name", "industry") VALUES ('a41deefd-e3e5-4fc7-8e7b-eb738ba3433c', 'Selkirk Rex', 'Birman');
INSERT INTO "company" ("id", "name", "industry") VALUES ('d40f9c41-d1ea-47c6-9287-3bc0f133dfb4', 'Birman', 'Oriental');
INSERT INTO "company" ("id", "name", "industry") VALUES ('56b95a4d-6378-4aa4-8317-860f2be569b3', 'Selkirk Rex', 'American Curl');
INSERT INTO "company" ("id", "name", "industry") VALUES ('50d523b6-19a6-4141-b695-47934c8b26ab', 'Bengal', 'Kurilian Bobtail');
INSERT INTO "company" ("id", "name", "industry") VALUES ('27eb88ab-05f5-427f-8223-36bbb212c7d2', 'Selkirk Rex', 'American Curl');

INSERT INTO "job" ("id", "title", "salary", "openingDate", "companyId") VALUES ('10f4516c-cbff-4690-9cdc-d50ef1056bae', 'Serengeti', 73303, '2024-06-03T06:33:01.122Z', '56b95a4d-6378-4aa4-8317-860f2be569b3');
INSERT INTO "job" ("id", "title", "salary", "openingDate", "companyId") VALUES ('e5e4d5ec-fb18-438a-967b-88278e8a5862', 'Tonkinese', 7463, '2023-09-15T16:37:40.766Z', 'a41deefd-e3e5-4fc7-8e7b-eb738ba3433c');
INSERT INTO "job" ("id", "title", "salary", "openingDate", "companyId") VALUES ('3246c956-e383-4768-9399-5521e8730e84', 'American Shorthair', 41309, '2024-02-13T13:53:29.222Z', '50d523b6-19a6-4141-b695-47934c8b26ab');
INSERT INTO "job" ("id", "title", "salary", "openingDate", "companyId") VALUES ('db7c9f1f-1b70-4d73-a166-d41d70064b24', 'Turkish Angora', 75347, '2023-08-09T11:52:45.544Z', '2b54df6b-e4e7-4441-8a99-cb1fefd12a64');
INSERT INTO "job" ("id", "title", "salary", "openingDate", "companyId") VALUES ('3dd110f5-5bc1-42dc-ab3e-ba698d000d67', 'Egyptian Mau', 41902, '2023-09-01T12:52:32.548Z', '27eb88ab-05f5-427f-8223-36bbb212c7d2');
INSERT INTO "job" ("id", "title", "salary", "openingDate", "companyId") VALUES ('243aac46-b415-48e2-8bfe-9e1387bc68fc', 'Bombay', 66945, '2023-11-09T01:56:28.592Z', 'd40f9c41-d1ea-47c6-9287-3bc0f133dfb4');
INSERT INTO "job" ("id", "title", "salary", "openingDate", "companyId") VALUES ('a643d68c-3995-48e1-b295-572f5c3de5a3', 'Turkish Angora', 92970, '2023-05-21T02:34:40.188Z', '4a46abec-691c-4aba-adf9-4f4bd9beb2c5');
INSERT INTO "job" ("id", "title", "salary", "openingDate", "companyId") VALUES ('a040f789-6b79-4fde-af70-33b023cefce3', 'Cornish Rex', 61763, '2024-08-26T00:28:37.634Z', 'a41deefd-e3e5-4fc7-8e7b-eb738ba3433c');
INSERT INTO "job" ("id", "title", "salary", "openingDate", "companyId") VALUES ('91b5224b-dcf6-4642-8751-f19ace42e3cf', 'Scottish Fold', 84487, '2023-07-26T08:24:36.984Z', '30196673-7503-4c1f-9423-2e61c071bd3d');
INSERT INTO "job" ("id", "title", "salary", "openingDate", "companyId") VALUES ('9277b614-3f08-40f2-9646-9bb36cbad6b7', 'Donskoy', 47792, '2023-05-31T03:21:41.261Z', '50d523b6-19a6-4141-b695-47934c8b26ab');

INSERT INTO "application" ("id", "applicationDate", "status", "userId", "jobId") VALUES ('47a05741-c8a6-4fb3-a798-787e2e7496f1', '2024-10-11T17:48:18.346Z', 'Havana', 'f8001b63-ec4a-4d42-87c6-7765fdeb4ac3', 'e5e4d5ec-fb18-438a-967b-88278e8a5862');
INSERT INTO "application" ("id", "applicationDate", "status", "userId", "jobId") VALUES ('ebac41e5-3943-433c-b04f-793d27726fd0', '2023-06-14T23:21:27.906Z', 'Peterbald', '49040fe6-75fb-4a5d-b828-b82e15aa7843', '243aac46-b415-48e2-8bfe-9e1387bc68fc');
INSERT INTO "application" ("id", "applicationDate", "status", "userId", "jobId") VALUES ('d8d4dcdc-dd68-4666-be8b-ec220148b47b', '2024-07-06T14:02:17.644Z', 'Manx', '661629cf-1bd8-4b96-86e4-c01a41d16d27', '9277b614-3f08-40f2-9646-9bb36cbad6b7');
INSERT INTO "application" ("id", "applicationDate", "status", "userId", "jobId") VALUES ('a4ca3154-4423-4bfc-bc60-f2da7a49a41e', '2024-01-30T19:41:15.417Z', 'Bengal', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', 'a040f789-6b79-4fde-af70-33b023cefce3');
INSERT INTO "application" ("id", "applicationDate", "status", "userId", "jobId") VALUES ('a69f78c6-247d-479b-8d88-a365eb4865c1', '2023-10-20T13:06:51.064Z', 'Korat', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', '10f4516c-cbff-4690-9cdc-d50ef1056bae');
INSERT INTO "application" ("id", "applicationDate", "status", "userId", "jobId") VALUES ('ed325f2f-5010-4a86-9aa8-0bfd5aa8c338', '2023-02-02T06:59:16.320Z', 'Minskin', '2f785f74-9d0a-475d-8429-10492ab2365b', '3246c956-e383-4768-9399-5521e8730e84');
INSERT INTO "application" ("id", "applicationDate", "status", "userId", "jobId") VALUES ('a8210df2-d3db-40e7-9d1c-c352f3af10be', '2023-04-06T04:02:38.026Z', 'LaPerm', 'f2e134ef-75eb-41b4-a461-6587918347f4', '3246c956-e383-4768-9399-5521e8730e84');
INSERT INTO "application" ("id", "applicationDate", "status", "userId", "jobId") VALUES ('933bb2fd-e046-4e71-a7ba-de207dc4a52c', '2023-06-20T05:48:53.012Z', 'Thai', 'f8001b63-ec4a-4d42-87c6-7765fdeb4ac3', 'db7c9f1f-1b70-4d73-a166-d41d70064b24');
INSERT INTO "application" ("id", "applicationDate", "status", "userId", "jobId") VALUES ('86244fb5-5898-4771-b0e6-1d44888b6e00', '2024-08-02T17:11:31.031Z', 'American Bobtail', '2f785f74-9d0a-475d-8429-10492ab2365b', '243aac46-b415-48e2-8bfe-9e1387bc68fc');
INSERT INTO "application" ("id", "applicationDate", "status", "userId", "jobId") VALUES ('ba4b4bbf-4830-4ed7-94d8-60171f54ea23', '2024-04-28T12:56:02.436Z', 'Serengeti', 'f2e134ef-75eb-41b4-a461-6587918347f4', '91b5224b-dcf6-4642-8751-f19ace42e3cf');

INSERT INTO "document" ("id", "filePath", "applicationId") VALUES ('476a7613-e347-4712-bce5-41b1367c967d', 'Serengeti', 'ed325f2f-5010-4a86-9aa8-0bfd5aa8c338');
INSERT INTO "document" ("id", "filePath", "applicationId") VALUES ('b19f3fcc-9eea-4c77-9506-fa91c996636f', 'British Shorthair', 'd8d4dcdc-dd68-4666-be8b-ec220148b47b');
INSERT INTO "document" ("id", "filePath", "applicationId") VALUES ('3aee8799-3f95-49c2-8fcb-6245ecd4ede8', 'Birman', 'a8210df2-d3db-40e7-9d1c-c352f3af10be');
INSERT INTO "document" ("id", "filePath", "applicationId") VALUES ('2f0f35f1-91c1-43c2-9d07-a94971a462b7', 'Siberian', 'a8210df2-d3db-40e7-9d1c-c352f3af10be');
INSERT INTO "document" ("id", "filePath", "applicationId") VALUES ('a1f25a18-b88f-4845-8743-252849090a7d', 'Highlander', 'a8210df2-d3db-40e7-9d1c-c352f3af10be');
INSERT INTO "document" ("id", "filePath", "applicationId") VALUES ('3af3becd-48ae-45ba-a5e5-d26e80d21929', 'Chausie', 'a69f78c6-247d-479b-8d88-a365eb4865c1');
INSERT INTO "document" ("id", "filePath", "applicationId") VALUES ('8ac01b61-fc40-4904-8204-f241dca19ee5', 'Kurilian Bobtail', 'ebac41e5-3943-433c-b04f-793d27726fd0');
INSERT INTO "document" ("id", "filePath", "applicationId") VALUES ('1f4ce7aa-a511-4471-9f24-3347f28e89f2', 'Donskoy', '47a05741-c8a6-4fb3-a798-787e2e7496f1');
INSERT INTO "document" ("id", "filePath", "applicationId") VALUES ('39e02777-0bef-499a-985e-e811b9d84341', 'Tonkinese', 'a4ca3154-4423-4bfc-bc60-f2da7a49a41e');
INSERT INTO "document" ("id", "filePath", "applicationId") VALUES ('ce801509-fb70-4287-8f61-1100134d31db', 'Burmese', 'a69f78c6-247d-479b-8d88-a365eb4865c1');

INSERT INTO "jobdescription" ("id", "description", "jobId") VALUES ('d9bd833a-9ac4-4595-9d2b-df0a77220464', 'Siamese', 'a643d68c-3995-48e1-b295-572f5c3de5a3');
INSERT INTO "jobdescription" ("id", "description", "jobId") VALUES ('08acf7a4-c5b0-4695-a864-daebd7c31b46', 'Bengal', '9277b614-3f08-40f2-9646-9bb36cbad6b7');
INSERT INTO "jobdescription" ("id", "description", "jobId") VALUES ('3d023661-aa7a-467e-a98f-98fc6b3a4089', 'Chausie', '9277b614-3f08-40f2-9646-9bb36cbad6b7');
INSERT INTO "jobdescription" ("id", "description", "jobId") VALUES ('0f669b6d-f9ba-410b-8034-0a06d61c9663', 'Oriental', '9277b614-3f08-40f2-9646-9bb36cbad6b7');
INSERT INTO "jobdescription" ("id", "description", "jobId") VALUES ('c3e8c537-ddcd-4b61-a393-437fa91464ad', 'Balinese', '10f4516c-cbff-4690-9cdc-d50ef1056bae');
INSERT INTO "jobdescription" ("id", "description", "jobId") VALUES ('02cf329d-73c7-4719-9c8c-ff151d28ceec', 'Pixiebob', '243aac46-b415-48e2-8bfe-9e1387bc68fc');
INSERT INTO "jobdescription" ("id", "description", "jobId") VALUES ('57ef882d-9e8b-4697-8f20-6539a4661f82', 'Oriental', '9277b614-3f08-40f2-9646-9bb36cbad6b7');
INSERT INTO "jobdescription" ("id", "description", "jobId") VALUES ('e3325d80-1d88-4543-af04-3d058e5fc2a7', 'Norwegian Forest Cat', 'a040f789-6b79-4fde-af70-33b023cefce3');
INSERT INTO "jobdescription" ("id", "description", "jobId") VALUES ('78be191f-dfc7-4a32-abce-6eeb698cf0e2', 'Sokoke', 'a643d68c-3995-48e1-b295-572f5c3de5a3');
INSERT INTO "jobdescription" ("id", "description", "jobId") VALUES ('e022fadb-c02e-4972-b636-d02273ac3d39', 'Selkirk Rex', '9277b614-3f08-40f2-9646-9bb36cbad6b7');
    `,
    )
    
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
